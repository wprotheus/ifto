CREATE TABLE tb_pessoa (id bigint NOT NULL,
                     nome VARCHAR (35),
                     PRIMARY KEY (id));

insert into tb_pessoa (id, nome) VALUES (1, 'wellington batista');
insert into tb_pessoa (id, nome) VALUES (2, 'wellington parreira');
insert into tb_pessoa (id, nome) VALUES (3, 'wellington neto');