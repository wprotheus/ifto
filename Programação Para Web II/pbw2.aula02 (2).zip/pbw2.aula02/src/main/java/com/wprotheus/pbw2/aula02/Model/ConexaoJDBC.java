package com.wprotheus.pbw2.aula02.Model;
import java.sql.Connection;

public interface ConexaoJDBC
{
	Connection criarConexao();

}
